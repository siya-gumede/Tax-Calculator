﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tax_Calculator.Models
{
    public class TaxResults
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ID {get; set;}
        [DataType(DataType.Date)]
        public DateTime submitted { get; set; }

        [Display(Name = "Postal Code")]
        public string postal_code { get; set; }
        [Display(Name = "Annual Income")]
        [Column(TypeName = "decimal(18, 2)")]
        public double annual_income {get; set;}
        public double tax { get; set; }
    }
    public class CalculatorContext : DbContext
    {
        public CalculatorContext(DbContextOptions<CalculatorContext> options)
            : base(options)
        {
        }

        public DbSet<TaxResults> TaxResult { get; set; }
    }
}

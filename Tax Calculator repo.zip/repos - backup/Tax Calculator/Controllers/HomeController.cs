﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tax_Calculator.Models;
using TaxCalculatorLibrary;
namespace Tax_Calculator.Controllers
{
    public class HomeController : Controller
    {
        private readonly CalculatorContext _context;

        public HomeController(CalculatorContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
           //Input form is a landing page and users are anonymous 
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Calculate( [Bind("postal_code,annual_income")] TaxResults calculate)
        {
            //Time calculation was submitted
            calculate.submitted = DateTime.Now;

            //Calculate Tax for this postal code
            calculate.tax = CalculateTax(calculate.postal_code,calculate.annual_income);
            if (ModelState.IsValid)
            {
                try  
                {
                    //Save changes to the database
                    _context.TaxResult.Add(calculate);                
                    await _context.SaveChangesAsync();                  
                }
                catch (DbUpdateConcurrencyException)
                {
                    
                }
                //Show results
                return View(calculate);
            }
            //Go back to input form
            return RedirectToAction(nameof(Index));
        }

        //Get Tax calculation from the Tax Calculator Library
        public double CalculateTax (string postal_code,double income)=> Tax.compute(postal_code, income);
       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

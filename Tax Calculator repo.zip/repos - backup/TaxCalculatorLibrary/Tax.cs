﻿using System;

namespace TaxCalculatorLibrary
{
    public class Tax
    {
        //Calculate Tax for a postal code
        public static double compute(string code, double income)
        {
            switch (TaxType(code))
            {
                case "Progressive": return Progressive(income);
                case "Flat Value": return FlatValue(income);
                case "Flat rate": return FlatRate(income);
                default: return FlatRate(income); 
            }
        }    

        //Get Tax type from postal code
        public static string TaxType(string code)
        {
            switch (code)
            {
                case "7441": return "Progressive";
                case "A100": return "Flat Value";
                case "7000": return "Flat rate";
                case "1000": return "Progressive";
                default : return "Unknown";
            }      
        }
        //Flat rate calculation
        public static double FlatRate (double income) => income * 0.175;
        //Flat value tax calculation
        public static double FlatValue(double income) => income >= 200000? 10000.00 : income * 0.05;
        //Progressive Tax Calculation
        public static double Progressive(double income)
        {
            double tax = 0;
            while (income > 0)
            {
                if (income >= 372951)
                { 
                tax += (income - 372950) * 0.35;
                income = 372950;
                }
                else if(income >= 171551)
                {
                    tax += (income - 171550) * 0.33;
                    income = 171550;
                }
                else if (income >= 82251)
                {
                    tax += (income - 82250) * 0.28;
                    income = 82250;
                }
                else if (income >= 33951)
                {
                    tax += (income - 33950) * 0.25;
                    income = 33950;
                }
                else if (income >= 8351)
                {
                    tax += (income - 8350) * 0.15;
                    income = 8350;
                }
                else
                {
                    tax += (income  * 0.10);
                    income = 0;
                }
            }
            return tax;
        }
    }
}

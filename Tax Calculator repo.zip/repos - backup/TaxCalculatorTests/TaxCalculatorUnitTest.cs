using NUnit.Framework;
using TaxCalculatorLibrary;
namespace Tests
{
    [TestFixture]
    public class Tests
    {

        [SetUp]
        public void Setup()
        {
            //1. Test Tax Type

            //2. Test Flat rate

            //3. Test Flat value

            //4. Test progressive 

            //5. Test Calculation where user gives a postal code and income

        }

        //Test Tax Type
        [TestCase("7441", "Progressive")]
        [TestCase("A100", "Flat Value")]
        [TestCase("7000", "Flat rate")]
        [TestCase("1000","Progressive")]
        public void TestTaxType(string value, string expectedType) => Assert.AreEqual(Tax.TaxType(value) , expectedType);

        //Test Flat rate
        [TestCase(10000, 10000 * 0.175)]
        [TestCase(100000, 100000 * 0.175)]
        [TestCase(1000000, 1000000 * 0.175)]
        [TestCase(10000000, 10000000 * 0.175)]
        public void TestFlatRate(double value,double expectedTax) => Assert.AreEqual( Tax.FlatRate(value), expectedTax);

        //Test Flat value
        [TestCase(10000, 10000 * 0.05)]
        [TestCase(15000, 15000 * 0.05)]
        [TestCase(200000, 10000.00)]
        [TestCase(20000000, 10000.00)]
        public void TestFlatValue(double value, double expectedTax) => Assert.AreEqual(Tax.FlatValue(value), expectedTax);

        //Test progressive
        [TestCase(8350, 8350 * 0.10)]
        [TestCase(8351, (8350 * 0.10)+(1 * 0.15))]
        [TestCase(33951, (1 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        [TestCase(82251, (1 * 0.28) + (48300 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        [TestCase(171551, (1 * 0.33) + (89300 * 0.28) + (48300 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        [TestCase(372951, (1 * 0.35)+ (201400 * 0.33) + (89300 * 0.28) + (48300 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        public void TestProgressive(double value, double expectedTax) => Assert.AreEqual(expectedTax,Tax.Progressive(value));

        //Test compute tax based on postal code and income
        [TestCase("A100", 8350, 8350 * 0.05)]
        [TestCase("7000", 8350, 8350 * 0.175)]
        [TestCase("7441", 8350, 8350 * 0.10)]
        [TestCase("1000", 8350, 8350 * 0.10)]

        [TestCase("A100", 372951, 10000)]
        [TestCase("7000", 372951, 372951 * 0.175)]
        [TestCase("7441", 372951, (1 * 0.35) + (201400 * 0.33) + (89300 * 0.28) + (48300 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        [TestCase("1000", 372951, (1 * 0.35) + (201400 * 0.33) + (89300 * 0.28) + (48300 * 0.25) + (8350 * 0.10) + (25600 * 0.15))]
        public void TestComputeTax(string code, double income, double expectedTax) => Assert.AreEqual(expectedTax, Tax.compute(code, income));

    }
}